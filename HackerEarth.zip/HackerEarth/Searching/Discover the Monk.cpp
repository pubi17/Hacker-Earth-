#include<bits/stdc++.h>
using namespace std ;
int main()
{
int q,n,x;
cin>>n>>q;

int arr[n];

for(int i=0;i<n;i++) cin>>arr[i];

sort (arr,arr+n);

while(q--){
cin>>x;

if(binary_search(arr,arr+n,x)){cout<<"yes";}

else {cout<<"NO \n";}
}
return 0;
}
