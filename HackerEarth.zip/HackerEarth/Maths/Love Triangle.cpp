#include<bits/stdc++.h>

using namespace std;
typedef long long ll;
ll mystery(ll x)
{
    if(x<9)
    {
        return x;
    }
    else
        return x%9+10*mystery(x/9);
}

int main()
{
    ll x;
    while(cin>>x)
    {
        cout<<mystery(x)<<"\n";
    }
    return 0;

}
